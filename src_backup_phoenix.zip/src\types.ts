// Core Type Definitions for the A-Z Self-Learning Platform

/**
 * Supported data domains for analysis
 */
export type Domain = 'finance' | 'biology' | 'education' | 'hr' | 'general';

/**
 * Standard Operating Procedure for a domain
 */
export interface SOP {
  source: string;
  objective: string;
  cleaning_rules: string[];
  chart_priorities: ChartType[];
  recommended_metrics: string[];      // NEW: Statistical metrics for this domain
  report_structure: string[];         // NEW: Academic section structure
}

/**
 * Supported chart types
 */
export type ChartType =
  | 'bar'
  | 'line'
  | 'scatter'
  | 'pie'
  | 'waterfall'
  | 'heatmap'
  | 'boxplot'
  | 'area'
  | 'radar';

/**
 * Cleaned and processed dataset
 */
export interface CleanedData {
  headers: string[];
  rows: Record<string, unknown>[];
  numericColumns: string[];
  categoricalColumns: string[];
  dateColumns: string[];
  rowCount: number;
  columnCount: number;
  cleaningLog: string[];              // NEW: Log of cleaning actions taken
  metadata: {
    originalFileName: string;
    cleanedAt: Date;
    rulesApplied: string[];
    mergeStrategy?: 'stack' | 'join' | 'single';
    joinKey?: string;
    filesCount?: number;
    matchRate?: number;
  };
}

/**
 * Model result from statistical analysis
 */
export interface ModelResult {
  feature: string;
  modelType: string;
  rSquared: number;
  correlation: number;
  insight: string;
}

/**
 * Statistical analysis results
 */
export interface StatisticalResults {
  rowCount: number;
  columnCount: number;
  numericSummary: Record<string, {
    mean: number;
    min: number;
    max: number;
    stdDev: number;
  }>;
  models: ModelResult[];
  correlations: Array<{
    feature1: string;
    feature2: string;
    correlation: number;
  }>;
}

/**
 * Chart configuration with scoring
 */
export interface ChartConfig {
  id: string;
  type: ChartType;
  title: string;
  description: string;
  data: Record<string, unknown>[];
  xAxisKey: string;
  yAxisKey: string;
  score: number;
  confidence: number;
  reasoning: string;
}

/**
 * Forecast result from predictive engine
 */
export interface ForecastResult {
  metric: string;
  dateColumn: string;
  trend: 'Upward' | 'Downward' | 'Stable';
  slope: number;
  confidence: string;
  historicalData: Record<string, unknown>[];
  forecastData: Record<string, unknown>[];
  combinedData: Record<string, unknown>[];
}

/**
 * Complete pipeline result
 */
export interface PipelineResult {
  domain: Domain;
  sop: SOP;
  data: CleanedData;
  charts: ChartConfig[];
  stats: StatisticalResults;
  forecast: ForecastResult | null;    // NEW: Predictive analysis
  cleaningLogs: string[];
  timestamp: Date;
}

/**
 * ML Learning weights structure
 */
export interface LearningWeights {
  [domain: string]: {
    [chartType: string]: number;
  };
}

/**
 * Report context for generation
 */
export interface ReportContext {
  sop: SOP;
  domain: Domain;
  cleaningLogs: string[];
  stats: StatisticalResults;
  forecast?: ForecastResult | null;
}

/**
 * Generated report output - Now with full academic structure
 */
export interface GeneratedReport {
  title: string;
  sections: ReportSection[];
  generatedAt: Date;
  // Legacy fields for backward compatibility
  blufSummary: string;
  detailedFindings: string[];
  recommendations: string[];
}

/**
 * Individual report section
 */
export interface ReportSection {
  title: string;
  content: string;
  subsections?: ReportSection[];
}
