/**
 * ReportHistoryPanel.tsx - Report History UI
 * 
 * Displays a list of saved reports with:
 * - Thumbnail preview
 * - Domain badge
 * - Quick actions (load, delete)
 */

import React, { useState, useEffect } from 'react';
import { Clock, Trash2, FileText, BarChart2, PieChart, TrendingUp, Search, X } from 'lucide-react';
import { reportHistory, type SavedReport } from '../engine/history/ReportHistory';
import './ReportHistoryPanel.css';

interface ReportHistoryPanelProps {
    isOpen: boolean;
    onClose: () => void;
    onLoadReport: (reportId: string) => void;
}

export const ReportHistoryPanel: React.FC<ReportHistoryPanelProps> = ({
    isOpen,
    onClose,
    onLoadReport
}) => {
    const [reports, setReports] = useState<SavedReport[]>([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [filter, setFilter] = useState<string>('all');

    useEffect(() => {
        if (isOpen) {
            loadReports();
        }
    }, [isOpen]);

    const loadReports = () => {
        const all = reportHistory.getReports();
        setReports(all);
    };

    const handleDelete = async (id: string, e: React.MouseEvent) => {
        e.stopPropagation();
        if (confirm('Delete this report?')) {
            await reportHistory.deleteReport(id);
            loadReports();
        }
    };

    const handleLoad = (id: string) => {
        onLoadReport(id);
        onClose();
    };

    const getChartIcon = (chartType?: string) => {
        switch (chartType) {
            case 'bar': return <BarChart2 size={16} />;
            case 'pie': return <PieChart size={16} />;
            case 'line': return <TrendingUp size={16} />;
            default: return <FileText size={16} />;
        }
    };

    const formatDate = (date: Date) => {
        const now = new Date();
        const diff = now.getTime() - date.getTime();
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));

        if (days === 0) {
            const hours = Math.floor(diff / (1000 * 60 * 60));
            if (hours === 0) {
                const mins = Math.floor(diff / (1000 * 60));
                return `${mins}m ago`;
            }
            return `${hours}h ago`;
        } else if (days === 1) {
            return 'Yesterday';
        } else if (days < 7) {
            return `${days}d ago`;
        } else {
            return date.toLocaleDateString();
        }
    };

    const filteredReports = reports.filter(r => {
        const matchesSearch = !searchQuery ||
            r.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
            r.domain.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesFilter = filter === 'all' || r.domain === filter;
        return matchesSearch && matchesFilter;
    });

    const domains = [...new Set(reports.map(r => r.domain))];
    const stats = reportHistory.getStats();

    if (!isOpen) return null;

    return (
        <div className="history-panel-overlay" onClick={onClose}>
            <div className="history-panel" onClick={e => e.stopPropagation()}>
                <div className="history-header">
                    <div className="history-title">
                        <Clock size={20} />
                        <h2>Report History</h2>
                        <span className="history-count">{reports.length}</span>
                    </div>
                    <button className="history-close" onClick={onClose}>
                        <X size={20} />
                    </button>
                </div>

                <div className="history-toolbar">
                    <div className="history-search">
                        <Search size={16} />
                        <input
                            type="text"
                            placeholder="Search reports..."
                            value={searchQuery}
                            onChange={e => setSearchQuery(e.target.value)}
                        />
                    </div>
                    <select
                        className="history-filter"
                        value={filter}
                        onChange={e => setFilter(e.target.value)}
                    >
                        <option value="all">All Domains</option>
                        {domains.map(d => (
                            <option key={d} value={d}>{d}</option>
                        ))}
                    </select>
                </div>

                {reports.length === 0 ? (
                    <div className="history-empty">
                        <FileText size={48} />
                        <p>No saved reports yet</p>
                        <span>Reports will appear here after analysis</span>
                    </div>
                ) : (
                    <>
                        <div className="history-stats">
                            <div className="stat-item">
                                <span className="stat-value">{stats.totalReports}</span>
                                <span className="stat-label">Reports</span>
                            </div>
                            <div className="stat-item">
                                <span className="stat-value">{stats.totalRowsAnalyzed.toLocaleString()}</span>
                                <span className="stat-label">Rows Analyzed</span>
                            </div>
                            <div className="stat-item">
                                <span className="stat-value">{Object.keys(stats.byDomain).length}</span>
                                <span className="stat-label">Domains</span>
                            </div>
                        </div>

                        <div className="history-list">
                            {filteredReports.map(report => (
                                <div
                                    key={report.id}
                                    className="history-item"
                                    onClick={() => handleLoad(report.id)}
                                >
                                    <div className="history-item-icon">
                                        {getChartIcon(report.thumbnailChart?.type)}
                                    </div>
                                    <div className="history-item-content">
                                        <div className="history-item-header">
                                            <span className="history-item-title">{report.title}</span>
                                            <span className={`history-item-domain ${report.domain}`}>
                                                {report.domain}
                                            </span>
                                        </div>
                                        <div className="history-item-meta">
                                            <span>{report.rowCount.toLocaleString()} rows</span>
                                            <span>•</span>
                                            <span>{report.chartCount} charts</span>
                                            <span>•</span>
                                            <span>{formatDate(report.createdAt)}</span>
                                        </div>
                                        {report.summary && (
                                            <p className="history-item-summary">
                                                {report.summary.slice(0, 100)}...
                                            </p>
                                        )}
                                    </div>
                                    <button
                                        className="history-item-delete"
                                        onClick={e => handleDelete(report.id, e)}
                                        title="Delete report"
                                    >
                                        <Trash2 size={16} />
                                    </button>
                                </div>
                            ))}
                        </div>
                    </>
                )}
            </div>
        </div>
    );
};

export default ReportHistoryPanel;
