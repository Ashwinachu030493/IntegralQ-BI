/**
 * Supabase Auth Configuration
 * 
 * Provides authentication context and hooks for the application.
 * Uses Supabase Auth for login, signup, and session management.
 */

// Auth configuration
export interface AuthConfig {
    supabaseUrl: string;
    supabaseAnonKey: string;
}

// User type
export interface User {
    id: string;
    email: string;
    name?: string;
    avatar_url?: string;
    role?: 'admin' | 'member' | 'viewer';
    org_id?: string;
}

// Auth state
export interface AuthState {
    user: User | null;
    isLoading: boolean;
    isAuthenticated: boolean;
    error: string | null;
}

// Session type
export interface Session {
    access_token: string;
    refresh_token: string;
    expires_at: number;
    user: User;
}

// Default config (uses mock in development)
const DEFAULT_CONFIG: AuthConfig = {
    supabaseUrl: import.meta.env.VITE_SUPABASE_URL || 'http://localhost:54321',
    supabaseAnonKey: import.meta.env.VITE_SUPABASE_ANON_KEY || 'mock-key'
};

// 🔒 SECURITY FIX: Auth bypass controlled by explicit env variable, not URL sniffing
const ENABLE_AUTH_BYPASS = import.meta.env.VITE_AUTH_BYPASS === 'true';

/**
 * Auth Service - handles all authentication operations
 */
class AuthService {
    private config: AuthConfig;
    private currentUser: User | null = null;
    private session: Session | null = null;
    private listeners: Set<(state: AuthState) => void> = new Set();

    constructor(config: AuthConfig = DEFAULT_CONFIG) {
        this.config = config;
        this.loadStoredSession();
    }

    /**
     * Load session from localStorage
     */
    private loadStoredSession(): void {
        try {
            const stored = localStorage.getItem('integralq_session');
            if (stored) {
                const session = JSON.parse(stored) as Session;
                if (session.expires_at > Date.now()) {
                    this.session = session;
                    this.currentUser = session.user;
                } else {
                    localStorage.removeItem('integralq_session');
                }
            }
        } catch (e) {
            console.error('[Auth] Failed to load stored session:', e);
        }
    }

    /**
     * Save session to localStorage
     */
    private saveSession(session: Session): void {
        localStorage.setItem('integralq_session', JSON.stringify(session));
        this.session = session;
        this.currentUser = session.user;
        this.notifyListeners();
    }

    /**
     * Notify all listeners of state change
     */
    private notifyListeners(): void {
        const state = this.getState();
        this.listeners.forEach(listener => listener(state));
    }

    /**
     * Get current auth state
     */
    getState(): AuthState {
        return {
            user: this.currentUser,
            isLoading: false,
            isAuthenticated: this.currentUser !== null,
            error: null
        };
    }

    /**
     * Subscribe to auth state changes
     */
    subscribe(listener: (state: AuthState) => void): () => void {
        this.listeners.add(listener);
        return () => this.listeners.delete(listener);
    }

    /**
     * Sign up with email and password
     */
    async signUp(email: string, password: string, name?: string): Promise<{ user: User | null; error: string | null }> {
        try {
            // 🔒 SECURITY: Use explicit env flag instead of URL sniffing
            if (ENABLE_AUTH_BYPASS) {
                console.warn('⚠️ SECURITY WARNING: Auth Bypass is Enabled (VITE_AUTH_BYPASS=true)');
                // Mock signup for development
                const mockUser: User = {
                    id: crypto.randomUUID(),
                    email,
                    name: name || email.split('@')[0],
                    role: 'member'
                };

                const mockSession: Session = {
                    access_token: `mock-token-${mockUser.id}`,
                    refresh_token: `mock-refresh-${mockUser.id}`,
                    expires_at: Date.now() + 7 * 24 * 60 * 60 * 1000, // 7 days
                    user: mockUser
                };

                this.saveSession(mockSession);
                console.log('[Auth] Mock signup successful:', email);
                return { user: mockUser, error: null };
            }

            // Real Supabase signup
            const response = await fetch(`${this.config.supabaseUrl}/auth/v1/signup`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'apikey': this.config.supabaseAnonKey
                },
                body: JSON.stringify({ email, password, data: { name } })
            });

            const data = await response.json();

            if (!response.ok) {
                return { user: null, error: data.error_description || data.msg || 'Signup failed' };
            }

            if (data.user) {
                const user: User = {
                    id: data.user.id,
                    email: data.user.email,
                    name: data.user.user_metadata?.name
                };

                if (data.session) {
                    const session: Session = {
                        access_token: data.session.access_token,
                        refresh_token: data.session.refresh_token,
                        expires_at: data.session.expires_at * 1000,
                        user
                    };
                    this.saveSession(session);
                }

                return { user, error: null };
            }

            return { user: null, error: 'Signup failed' };
        } catch (e) {
            console.error('[Auth] Signup error:', e);

            // Auto-fallback for Demo Mode on network error
            console.warn('⚠️ Network error detected. Falling back to Demo Mode.');
            const mockUser: User = {
                id: crypto.randomUUID(),
                email,
                name: name || email.split('@')[0],
                role: 'member'
            };

            const mockSession: Session = {
                access_token: `mock-token-${mockUser.id}`,
                refresh_token: `mock-refresh-${mockUser.id}`,
                expires_at: Date.now() + 7 * 24 * 60 * 60 * 1000,
                user: mockUser
            };

            this.saveSession(mockSession);
            return { user: mockUser, error: null };
        }
    }

    /**
     * Sign in with email and password
     */
    async signIn(email: string, password: string): Promise<{ user: User | null; error: string | null }> {
        try {
            // 🔒 SECURITY: Use explicit env flag instead of URL sniffing
            if (ENABLE_AUTH_BYPASS) {
                console.warn('⚠️ SECURITY WARNING: Auth Bypass is Enabled (VITE_AUTH_BYPASS=true)');
                const mockUser: User = {
                    id: crypto.randomUUID(),
                    email,
                    name: email.split('@')[0],
                    role: 'admin'
                };

                const mockSession: Session = {
                    access_token: `mock-token-${mockUser.id}`,
                    refresh_token: `mock-refresh-${mockUser.id}`,
                    expires_at: Date.now() + 7 * 24 * 60 * 60 * 1000,
                    user: mockUser
                };

                this.saveSession(mockSession);
                console.log('[Auth] Mock signin successful:', email);
                return { user: mockUser, error: null };
            }

            // Real Supabase signin
            const response = await fetch(`${this.config.supabaseUrl}/auth/v1/token?grant_type=password`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'apikey': this.config.supabaseAnonKey
                },
                body: JSON.stringify({ email, password })
            });

            const data = await response.json();

            if (!response.ok) {
                return { user: null, error: data.error_description || 'Invalid credentials' };
            }

            const user: User = {
                id: data.user.id,
                email: data.user.email,
                name: data.user.user_metadata?.name
            };

            const session: Session = {
                access_token: data.access_token,
                refresh_token: data.refresh_token,
                expires_at: data.expires_at * 1000,
                user
            };

            this.saveSession(session);
            return { user, error: null };
        } catch (e) {
            console.error('[Auth] Signin error:', e);

            // Auto-fallback for Demo Mode on network error
            console.warn('⚠️ Network error detected. Falling back to Demo Mode.');
            const mockUser: User = {
                id: crypto.randomUUID(),
                email,
                name: email.split('@')[0],
                role: 'admin'
            };

            const mockSession: Session = {
                access_token: `mock-token-${mockUser.id}`,
                refresh_token: `mock-refresh-${mockUser.id}`,
                expires_at: Date.now() + 7 * 24 * 60 * 60 * 1000,
                user: mockUser
            };

            this.saveSession(mockSession);
            return { user: mockUser, error: null };
        }
    }

    /**
     * Sign out
     */
    async signOut(): Promise<void> {
        localStorage.removeItem('integralq_session');
        this.currentUser = null;
        this.session = null;
        this.notifyListeners();
        console.log('[Auth] Signed out');
    }

    /**
     * Get current user
     */
    getUser(): User | null {
        return this.currentUser;
    }

    /**
     * Get access token for API calls
     */
    getAccessToken(): string | null {
        return this.session?.access_token || null;
    }

    /**
     * Check if user is authenticated
     */
    isAuthenticated(): boolean {
        return this.currentUser !== null;
    }
}

// Singleton instance
export const authService = new AuthService();

export default authService;
