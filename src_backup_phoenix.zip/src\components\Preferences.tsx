/**
 * Preferences.tsx - User Preferences Modal
 * 
 * Allows users to configure app preferences:
 * - Theme (dark/light)
 * - LLM Provider selection
 * - Notification settings
 * - Data processing options
 */

import React, { useState, useEffect } from 'react';
import { X, Settings, Sun, Brain, Bell, Database, Save, Loader2 } from 'lucide-react';
import { llmBridge } from '../engine/llm/LLMBridge';
import './Preferences.css';

interface PreferencesProps {
    isOpen: boolean;
    onClose: () => void;
}

interface UserPreferences {
    theme: 'dark' | 'light' | 'system';
    llmProvider: 'mock' | 'openai' | 'anthropic' | 'ollama';
    notificationsEnabled: boolean;
    autoSaveReports: boolean;
    defaultDomain: string;
}

const STORAGE_KEY = 'integralq_preferences';

const getStoredPreferences = (): UserPreferences => {
    try {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) {
            return JSON.parse(stored);
        }
    } catch { /* ignore */ }

    return {
        theme: 'dark',
        llmProvider: 'mock',
        notificationsEnabled: true,
        autoSaveReports: true,
        defaultDomain: 'general'
    };
};

export const Preferences: React.FC<PreferencesProps> = ({
    isOpen,
    onClose
}) => {
    const [prefs, setPrefs] = useState<UserPreferences>(getStoredPreferences());
    const [saving, setSaving] = useState(false);
    const [saved, setSaved] = useState(false);

    useEffect(() => {
        if (isOpen) {
            setPrefs(getStoredPreferences());
            setSaved(false);
        }
    }, [isOpen]);

    if (!isOpen) return null;

    const handleSave = async () => {
        setSaving(true);

        try {
            // Save to localStorage
            localStorage.setItem(STORAGE_KEY, JSON.stringify(prefs));

            // Apply LLM provider change
            llmBridge.setConfig({ provider: prefs.llmProvider });

            setSaved(true);
            setTimeout(() => {
                onClose();
            }, 1000);
        } finally {
            setSaving(false);
        }
    };

    const updatePref = <K extends keyof UserPreferences>(
        key: K,
        value: UserPreferences[K]
    ) => {
        setPrefs(prev => ({ ...prev, [key]: value }));
        setSaved(false);
    };

    return (
        <div className="prefs-modal-overlay" onClick={onClose}>
            <div className="prefs-modal" onClick={e => e.stopPropagation()}>
                <div className="prefs-modal-header">
                    <h2><Settings size={20} /> Preferences</h2>
                    <button className="prefs-close" onClick={onClose}>
                        <X size={20} />
                    </button>
                </div>

                <div className="prefs-content">
                    {/* Theme */}
                    <div className="prefs-section">
                        <h3><Sun size={18} /> Appearance</h3>
                        <div className="prefs-option">
                            <label>Theme</label>
                            <select
                                value={prefs.theme}
                                onChange={e => updatePref('theme', e.target.value as UserPreferences['theme'])}
                            >
                                <option value="dark">Dark</option>
                                <option value="light">Light (Coming Soon)</option>
                                <option value="system">System</option>
                            </select>
                        </div>
                    </div>

                    {/* AI Settings */}
                    <div className="prefs-section">
                        <h3><Brain size={18} /> AI Settings</h3>
                        <div className="prefs-option">
                            <label>LLM Provider</label>
                            <select
                                value={prefs.llmProvider}
                                onChange={e => updatePref('llmProvider', e.target.value as UserPreferences['llmProvider'])}
                            >
                                <option value="mock">Mock (Demo)</option>
                                <option value="openai">OpenAI (GPT-4)</option>
                                <option value="anthropic">Anthropic (Claude)</option>
                                <option value="ollama">Ollama (Local)</option>
                            </select>
                            <span className="prefs-hint">
                                {prefs.llmProvider === 'mock' && 'Uses simulated AI responses for demo'}
                                {prefs.llmProvider === 'openai' && 'Requires OPENAI_API_KEY in .env'}
                                {prefs.llmProvider === 'anthropic' && 'Requires ANTHROPIC_API_KEY in .env'}
                                {prefs.llmProvider === 'ollama' && 'Requires Ollama running locally'}
                            </span>
                        </div>
                    </div>

                    {/* Notifications */}
                    <div className="prefs-section">
                        <h3><Bell size={18} /> Notifications</h3>
                        <div className="prefs-toggle">
                            <label>
                                <span>Enable Notifications</span>
                                <input
                                    type="checkbox"
                                    checked={prefs.notificationsEnabled}
                                    onChange={e => updatePref('notificationsEnabled', e.target.checked)}
                                />
                                <span className="toggle-switch"></span>
                            </label>
                        </div>
                    </div>

                    {/* Data */}
                    <div className="prefs-section">
                        <h3><Database size={18} /> Data</h3>
                        <div className="prefs-toggle">
                            <label>
                                <span>Auto-save Reports</span>
                                <input
                                    type="checkbox"
                                    checked={prefs.autoSaveReports}
                                    onChange={e => updatePref('autoSaveReports', e.target.checked)}
                                />
                                <span className="toggle-switch"></span>
                            </label>
                        </div>
                        <div className="prefs-option">
                            <label>Default Domain</label>
                            <select
                                value={prefs.defaultDomain}
                                onChange={e => updatePref('defaultDomain', e.target.value)}
                            >
                                <option value="general">Auto-detect</option>
                                <option value="finance">Finance</option>
                                <option value="hr">Human Resources</option>
                                <option value="education">Education</option>
                                <option value="biology">Biology</option>
                            </select>
                        </div>
                    </div>

                    {saved && (
                        <div className="prefs-saved">
                            ✓ Preferences saved!
                        </div>
                    )}

                    <button
                        className="prefs-save-btn"
                        onClick={handleSave}
                        disabled={saving}
                    >
                        {saving ? (
                            <>
                                <Loader2 size={18} className="spinner" />
                                Saving...
                            </>
                        ) : (
                            <>
                                <Save size={18} />
                                Save Preferences
                            </>
                        )}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default Preferences;
