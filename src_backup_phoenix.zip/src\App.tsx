/**
 * App.tsx - The Main Application
 * * Connects the UI to the AnalysisDirector pipeline.
 * Features:
 * - Hybrid Processing (Python Backend + Client-Side Fallback)
 * - File drop zone for data ingestion
 * - Protocol Header showing SOP source & objective
 * - Chart Grid with checkboxes for selection
 * - Manual chart type switcher for ML acceleration
 * - Generate Report button with ML feedback recording
 * - Knowledge Base (SOP) Toggle
 */

import React, { useState, useCallback, useRef, useEffect } from 'react';
import {
  BarChart, Bar, LineChart, Line, ScatterChart, Scatter,
  PieChart, Pie, Cell, AreaChart, Area,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from 'recharts';

import { GlassCard } from './components/GlassCard';

// Engine & Logic Imports
import { analysisDirector } from './engine/AnalysisDirector';
import { finalReportGenerator } from './engine/narrator/FinalReportGenerator';
import { feedbackLoop } from './engine/learning/FeedbackLoop';
import { pdfGenerator } from './engine/export/PDFGenerator';
import { apiClient, type BackendAnalysisResult } from './api/client';
import { useAuth } from './auth/AuthProvider';

// Component Imports
import { DataChat } from './components/DataChat';
import { DashboardLayout } from './components/DashboardLayout';
import { LoginPage } from './components/LoginPage';
import { SOPManager } from './components/SOPManager';

// Types & Styles
import type { PipelineResult, ChartConfig, ChartType, GeneratedReport, Domain } from './types';
import './App.css';

// ----------------------------------------------------------------------
// Constants
// ----------------------------------------------------------------------

const CHART_COLORS = [
  '#6366f1', '#8b5cf6', '#ec4899', '#f43f5e', '#f97316',
  '#eab308', '#22c55e', '#14b8a6', '#06b6d4', '#3b82f6'
];

const SWITCHABLE_CHART_TYPES: ChartType[] = ['bar', 'line', 'pie', 'scatter', 'area'];

// ----------------------------------------------------------------------
// Main Component
// ----------------------------------------------------------------------

function App() {
  // --- Auth State ---
  const { isAuthenticated, user: _user, signOut: _signOut, isLoading: authLoading } = useAuth();

  // --- Application State ---
  const [pipelineResult, setPipelineResult] = useState<PipelineResult | null>(null);
  const [selectedChartIds, setSelectedChartIds] = useState<Set<string>>(new Set());
  const [isProcessing, setIsProcessing] = useState(false);
  const [report, setReport] = useState<GeneratedReport | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);

  // UI Interaction State
  const [chartTypeOverrides, setChartTypeOverrides] = useState<Record<string, ChartType>>({});
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);
  const [activeView, setActiveView] = useState<'dashboard' | 'sop'>('dashboard');

  // Infrastructure State
  const [backendStatus, setBackendStatus] = useState<'checking' | 'connected' | 'disconnected'>('checking');
  const chartGridRef = useRef<HTMLDivElement>(null);

  // --- Effects ---

  // Check backend availability on mount
  useEffect(() => {
    const checkBackend = async () => {
      try {
        const isAvailable = await apiClient.checkHealth();
        setBackendStatus(isAvailable ? 'connected' : 'disconnected');
      } catch (e) {
        setBackendStatus('disconnected');
      }
    };
    checkBackend();
  }, []);

  // (Auth checks moved to bottom to satisfy Rules of Hooks)

  // --- Handlers ---

  /**
   * Handle file drop - Hybrid Architecture
   * Tries Python backend first for power, falls back to Client-Side JS for reliability.
   */
  const handleDrop = useCallback(async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
    setError(null);
    setReport(null);
    setChartTypeOverrides({});

    const files = Array.from(e.dataTransfer.files);

    if (files.length === 0) {
      setError('No files were dropped');
      return;
    }

    // Validate file types
    const validExtensions = ['.csv', '.json', '.xlsx', '.xls'];
    const validFiles = files.filter(f =>
      validExtensions.some(ext => f.name.toLowerCase().endsWith(ext))
    );

    if (validFiles.length === 0) {
      setError('Please drop CSV, JSON, or Excel files');
      return;
    }

    try {
      setIsProcessing(true);
      let result: PipelineResult;

      // 1. Try Backend (FastAPI/Pandas)
      if (backendStatus === 'connected') {
        try {
          console.log('[App] Using backend API for processing...');
          const backendResult: BackendAnalysisResult = await apiClient.analyzeFiles(validFiles);

          // 2. Hydrate Client-Side Charts (Hybrid Approach)
          // We use backend for heavy stats, but client pipeline for Chart Configs
          const clientResult = await analysisDirector.runPipeline(validFiles);

          // Merge backend accuracy with client visuals
          result = {
            ...clientResult,
            stats: {
              ...clientResult.stats,
              rowCount: backendResult.row_count,
              models: backendResult.statistics.models.map(m => ({
                feature: m.feature,
                correlation: m.correlation,
                insight: m.insight,
                modelType: m.type || 'correlation',
                rSquared: m.correlation * m.correlation
              }))
            },
            cleaningLogs: backendResult.cleaning_log
          };
          console.log('[App] Hybrid processing complete');
        } catch (backendError) {
          console.warn('[App] Backend failed, falling back to client-side:', backendError);
          result = await analysisDirector.runPipeline(validFiles);
        }
      } else {
        // 3. Fallback to Client-Side (Browser JS)
        console.log('[App] Using client-side processing...');
        result = await analysisDirector.runPipeline(validFiles);
      }

      setPipelineResult(result);

      // Auto-select top 3 charts based on confidence
      const topChartIds = result.charts.slice(0, 3).map(c => c.id);
      setSelectedChartIds(new Set(topChartIds));

    } catch (err) {
      console.error('[App] Pipeline error:', err);
      setError(err instanceof Error ? err.message : 'Failed to process files');
    } finally {
      setIsProcessing(false);
    }
  }, [backendStatus]);

  const handleDragOver = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
  }, []);

  const toggleChartSelection = useCallback((chartId: string) => {
    setSelectedChartIds(prev => {
      const next = new Set(prev);
      if (next.has(chartId)) next.delete(chartId);
      else next.add(chartId);
      return next;
    });
  }, []);

  /**
   * Handle Chart Type Switching (ML Feedback)
   */
  const handleChartTypeSwitch = useCallback((chartId: string, newType: ChartType) => {
    setChartTypeOverrides(prev => ({
      ...prev,
      [chartId]: newType
    }));

    // Record implicit feedback for RL engine
    if (pipelineResult) {
      const chart = pipelineResult.charts.find(c => c.id === chartId);
      if (chart) {
        feedbackLoop.recordInteraction(
          pipelineResult.domain,
          [newType], // Selected
          [chart.type] // Rejected (the old type)
        );
      }
    }
  }, [pipelineResult]);

  /**
   * Generate PDF Report
   */
  const generateReport = async () => {
    if (!pipelineResult) return;

    try {
      setIsGeneratingPDF(true);

      const selectedCharts = pipelineResult.charts
        .filter(c => selectedChartIds.has(c.id))
        .map(c => ({
          ...c,
          type: chartTypeOverrides[c.id] || c.type
        }));

      if (selectedCharts.length === 0) {
        setError('Please select at least one chart for the report');
        setIsGeneratingPDF(false);
        return;
      }

      // Generate Text Content (LLM + Logic)
      const reportData = await finalReportGenerator.generate(
        selectedCharts,
        pipelineResult.sop.objective, // 2nd Arg: Objective (string)
        pipelineResult.domain as Domain, // 3rd Arg: Domain (Domain type)
        {
          sop: pipelineResult.sop,
          stats: pipelineResult.stats,
          cleaningLogs: pipelineResult.cleaningLogs,
          domain: pipelineResult.domain as Domain
        }
      );

      setReport(reportData);

      // Generate Visual PDF
      if (chartGridRef.current) {
        setTimeout(async () => {
          await pdfGenerator.generate(reportData, pipelineResult, selectedCharts, chartGridRef.current!);
          setIsGeneratingPDF(false);
        }, 100);
      }

    } catch (err) {
      console.error('Report generation failed:', err);
      setError('Failed to generate report');
      setIsGeneratingPDF(false);
    }
  };

  // --- Early Returns for Auth (Moved down to fix Hook Order) ---

  if (authLoading) {
    return (
      <div className="auth-loading">
        <div className="loading-spinner"></div>
        <p>Loading...</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginPage />;
  }

  // --- Rendering Helpers ---

  const renderChart = (config: ChartConfig) => {
    const activeType = chartTypeOverrides[config.id] || config.type;
    const data = config.data;

    const commonProps = {
      data,
      margin: { top: 10, right: 30, left: 0, bottom: 0 }
    };

    const tooltipStyle = { backgroundColor: '#1f2937', border: 'none', borderRadius: '8px', color: '#fff' };

    switch (activeType) {
      case 'bar':
        return (
          <BarChart {...commonProps}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis dataKey="name" stroke="#9ca3af" />
            <YAxis stroke="#9ca3af" />
            <Tooltip contentStyle={tooltipStyle} />
            <Legend />
            <Bar dataKey="value" fill={CHART_COLORS[0]} radius={[4, 4, 0, 0]} />
          </BarChart>
        );
      case 'line':
        return (
          <LineChart {...commonProps}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis dataKey="name" stroke="#9ca3af" />
            <YAxis stroke="#9ca3af" />
            <Tooltip contentStyle={tooltipStyle} />
            <Legend />
            <Line type="monotone" dataKey="value" stroke={CHART_COLORS[1]} strokeWidth={2} dot={{ r: 4 }} />
          </LineChart>
        );
      case 'area':
        return (
          <AreaChart {...commonProps}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis dataKey="name" stroke="#9ca3af" />
            <YAxis stroke="#9ca3af" />
            <Tooltip contentStyle={tooltipStyle} />
            <Legend />
            <Area type="monotone" dataKey="value" stroke={CHART_COLORS[2]} fill={CHART_COLORS[2]} fillOpacity={0.3} />
          </AreaChart>
        );
      case 'pie':
        return (
          <PieChart>
            <Pie
              data={data}
              dataKey="value"
              nameKey="name"
              cx="50%"
              cy="50%"
              outerRadius={80}
              label
            >
              {data.map((_: any, index: number) => (
                <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
              ))}
            </Pie>
            <Tooltip contentStyle={tooltipStyle} />
            <Legend />
          </PieChart>
        );
      case 'scatter':
        return (
          <ScatterChart {...commonProps}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis type="category" dataKey="name" name="category" stroke="#9ca3af" />
            <YAxis type="number" dataKey="value" name="value" stroke="#9ca3af" />
            <Tooltip cursor={{ strokeDasharray: '3 3' }} contentStyle={tooltipStyle} />
            <Legend />
            <Scatter name="Data" data={data} fill={CHART_COLORS[4]} />
          </ScatterChart>
        );
      default:
        return null;
    }
  };

  // --- Main Render ---

  return (
    <DashboardLayout
      isAuthenticated={isAuthenticated}
      user={_user}
      onSignOut={_signOut}
      activeView={activeView}
      onNavigate={setActiveView}
    >
      {activeView === 'sop' ? (
        <SOPManager />
      ) : (
        <div className="app-container animate-in fade-in duration-500">

          {/* HEADER: Minimalist - Only Status & Version */}
          <header className="app-header">
            <div className="flex flex-col">
              <h2 className="text-2xl font-bold text-white">Analytics Dashboard</h2>
              <p className="text-gray-400 text-sm">Upload data to generate domain-aware insights</p>
            </div>

            <div className="status-bar flex items-center gap-4">
              <span className="version">v2.0 Hybrid</span>
              <div className={`status-indicator ${backendStatus}`}>
                <div className="status-dot"></div>
                <span>{backendStatus === 'connected' ? 'Online' : 'Offline'}</span>
              </div>
            </div>
          </header>

          <main className="main-content">
            {/* Analysis Configuration / SOP Header */}
            {pipelineResult && (
              <div className="pipeline-header">
                <div className="domain-badge">
                  <span className="label">Domain Detected:</span>
                  <span className="value">{pipelineResult.domain.toUpperCase()}</span>
                </div>
                {pipelineResult.sop && (
                  <div className="sop-info">
                    <span className="label">Active SOP:</span>
                    <span className="value">{pipelineResult.sop.source}</span>
                    <p className="objective">{pipelineResult.sop.objective}</p>
                  </div>
                )}
              </div>
            )}

            {/* Upload Zone */}
            {!pipelineResult && !isProcessing && (
              <div
                className={`upload-zone ${isDragOver ? 'drag-over' : ''} ${error ? 'error' : ''}`}
                onDrop={handleDrop}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
              >
                <div className="upload-content">
                  <div className="upload-icon">📂</div>
                  <h3>Drag & Drop Data Files</h3>
                  <p>Support for CSV, Excel, JSON</p>
                  <p className="sub-text">AI automatically detects domain & selects SOPs</p>
                  {error && <p className="error-message">{error}</p>}
                </div>
              </div>
            )}

            {/* Processing State */}
            {isProcessing && (
              <div className="processing-state">
                <div className="loading-spinner"></div>
                <h3>Analyzing data structure...</h3>
                <p>Applying domain protocols & cleaning rules</p>
              </div>
            )}

            {/* Results Grid */}
            {pipelineResult && (
              <>
                <section className="analysis-grid" ref={chartGridRef}>
                  <div className="section-header">
                    <h2>
                      <span>📊 Generated Insights</span>
                      <span className="count-badge">{pipelineResult.charts.length} Charts</span>
                    </h2>
                    <div className="actions">
                      <button
                        className="btn-primary"
                        onClick={generateReport}
                        disabled={selectedChartIds.size === 0 || isGeneratingPDF}
                      >
                        {isGeneratingPDF ? 'Generating...' : 'Download Report'}
                      </button>
                    </div>
                  </div>

                  {/* Restored Stats Header */}
                  {pipelineResult && (
                    <div className="bg-gray-800/50 border border-gray-700 rounded-xl p-6 mb-8 backdrop-blur-sm">
                      <div className="flex justify-between items-start">
                        <div>
                          <span className="bg-indigo-600 text-xs font-bold px-2 py-1 rounded text-white uppercase tracking-wider">
                            Domain: {pipelineResult.domain}
                          </span>
                          <p className="mt-2 text-gray-400 text-sm max-w-2xl">{pipelineResult.sop.objective}</p>
                        </div>

                        <div className="flex gap-8 text-center">
                          <div>
                            <div className="text-2xl font-bold text-white">{pipelineResult.stats.rowCount}</div>
                            <div className="text-xs text-gray-500 uppercase">Rows</div>
                          </div>
                          <div>
                            <div className="text-2xl font-bold text-white">{pipelineResult.stats.columnCount}</div>
                            <div className="text-xs text-gray-500 uppercase">Columns</div>
                          </div>
                          <div>
                            <div className="text-2xl font-bold text-emerald-400">{pipelineResult.charts.length}</div>
                            <div className="text-xs text-gray-500 uppercase">Charts</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-1">
                    {pipelineResult.charts.map(chart => (
                      <GlassCard
                        key={chart.id}
                        title={chart.title}
                        // Convert confidence (0.85) to Score (85)
                        score={Math.round(chart.confidence * 100)}
                        // Show chart type as a badge
                        badge={chartTypeOverrides[chart.id] || chart.type}
                        // Handle selection state
                        selected={selectedChartIds.has(chart.id)}
                        onSelect={() => toggleChartSelection(chart.id)}
                        className="animate-in fade-in zoom-in duration-300"
                      >
                        {/* 1. Chart Controls (Type Switcher) */}
                        <div className="chart-controls mb-4 flex gap-2 justify-end" onClick={e => e.stopPropagation()}>
                          {SWITCHABLE_CHART_TYPES.map(type => (
                            <button
                              key={type}
                              className={`type-btn text-xs px-2 py-1 rounded ${type === (chartTypeOverrides[chart.id] || chart.type) ? 'bg-indigo-600 text-white' : 'bg-gray-700 text-gray-400'}`}
                              onClick={() => handleChartTypeSwitch(chart.id, type)}
                              title={`Switch to ${type}`}
                            >
                              {type.charAt(0).toUpperCase()}
                            </button>
                          ))}
                        </div>

                        {/* 2. Visuals */}
                        <div className="h-64 w-full">
                          <ResponsiveContainer width="100%" height="100%">
                            {renderChart(chart) || <div className="text-gray-500 flex items-center justify-center h-full">Invalid Data</div>}
                          </ResponsiveContainer>
                        </div>

                        {/* 3. Insight Footer */}
                        <div className="mt-4 pt-4 border-t border-gray-700">
                          <p className="text-sm text-gray-300 italic">
                            💡 {chart.reasoning}
                          </p>
                        </div>
                      </GlassCard>
                    ))}
                  </div>
                </section>

                {/* Cleaning Log */}
                <section className="cleaning-log">
                  <h2 className="section-title">
                    <span>🧹 Data Cleaning Log</span>
                  </h2>
                  <div className="log-container">
                    <ul>
                      {pipelineResult.cleaningLogs.map((log, i) => (
                        <li key={i}>{log}</li>
                      ))}
                    </ul>
                  </div>
                </section>

                {/* Report Display */}
                {report && (
                  <section className="report-section">
                    <h2 className="section-title">
                      <span>📋 Executive Report</span>
                    </h2>

                    <div className="report-card">
                      <h3 className="report-title">{report.title}</h3>
                      <p className="report-timestamp">
                        Generated: {report.generatedAt.toLocaleString()}
                      </p>

                      <div className="report-bluf">
                        <h4>🎯 Executive Summary (BLUF)</h4>
                        <p>{report.blufSummary}</p>
                      </div>

                      <div className="report-findings">
                        <h4>📊 Detailed Findings</h4>
                        <ul>
                          {report.detailedFindings.map((finding, i) => (
                            <li key={i}>{finding}</li>
                          ))}
                        </ul>
                      </div>

                      <div className="report-recommendations">
                        <h4>💡 Recommendations</h4>
                        <ol>
                          {report.recommendations.map((rec, i) => (
                            <li key={i}>{rec}</li>
                          ))}
                        </ol>
                      </div>
                    </div>
                  </section>
                )}
              </>
            )}
          </main>

          <footer className="footer">
            <p>IntegralQ-BI - RAG + ML Feedback Loop - Built with React + TypeScript</p>
          </footer>

          {pipelineResult && <DataChat context={pipelineResult} />}
        </div>
      )}
    </DashboardLayout>
  );
}

export default App;
