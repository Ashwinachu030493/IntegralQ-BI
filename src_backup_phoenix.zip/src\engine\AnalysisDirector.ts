/**
 * AnalysisDirector.ts - The Orchestrator
 * 
 * Controls the complete data analysis pipeline:
 * 1. Parse Data (quick parse for domain detection)
 * 2. Detect Domain -> DomainDetector
 * 3. Ingest & Clean Data with correct domain -> UniversalCleaner
 * 4. RAG Lookup -> SOPLibrary
 * 5. Statistical Analysis -> StatisticalAnalyzer
 * 6. ML Lookup -> FeedbackLoop
 * 7. Generate Charts -> ChartFactory
 * 8. Score Charts -> Scoring Algorithm
 * 9. Return Complete Result with Stats & Logs
 */

import type { PipelineResult, ChartConfig, ChartType, CleanedData } from '../types';
import { universalCleaner } from './cleaning/UniversalCleaner';
import { domainDetector } from './detection/DomainDetector';
import { getSOP } from './rag/SOPLibrary';
import { feedbackLoop } from './learning/FeedbackLoop';
import { chartFactory } from './charts/ChartFactory';
import { statisticalAnalyzer } from './analysis/StatisticalAnalyzer';
import { ForecastEngine } from './analysis/ForecastEngine';
import { SmartMerger } from './ingest/SmartMerger';

/**
 * AnalysisDirector - Orchestrates the complete RAG + ML pipeline
 */
export class AnalysisDirector {
    /**
     * Run the complete analysis pipeline
     * FIX: Now detects domain FIRST before cleaning
     */
    async runPipeline(files: File[]): Promise<PipelineResult> {
        console.log('[Director] Starting pipeline with', files.length, 'file(s)');

        // 🛡️ SECURITY GATE - Mitigate xlsx vulnerability (GHSA-4r6h-8v6p-xvw6)
        const ALLOWED_MIMES = [
            'application/vnd.ms-excel',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'text/csv',
            'text/plain' // Some systems report CSV as text/plain
        ];
        const ALLOWED_EXTENSIONS = ['xls', 'xlsx', 'csv'];
        const MAX_FILE_SIZE = 25 * 1024 * 1024; // 25MB limit

        const safeFiles = files.filter(file => {
            // 1. Extension Check
            const ext = file.name.split('.').pop()?.toLowerCase() || '';
            if (!ALLOWED_EXTENSIONS.includes(ext)) {
                console.warn(`[Security] Rejected ${file.name} (Invalid extension: ${ext})`);
                return false;
            }

            // 2. MIME Type Check (allow empty for Windows CSV edge case)
            if (file.type !== '' && !ALLOWED_MIMES.includes(file.type)) {
                console.warn(`[Security] Rejected ${file.name} (Invalid MIME: ${file.type})`);
                return false;
            }

            // 3. Size Limit Check
            if (file.size > MAX_FILE_SIZE) {
                console.warn(`[Security] Rejected ${file.name} (Too large: ${(file.size / 1024 / 1024).toFixed(1)}MB > 25MB)`);
                return false;
            }

            console.log(`[Security] Accepted ${file.name} (${ext}, ${(file.size / 1024).toFixed(0)}KB)`);
            return true;
        });

        if (safeFiles.length === 0) {
            throw new Error('No valid files to process. Ensure files are .xls, .xlsx, or .csv and under 25MB.');
        }

        // Step 1: Quick Parse for Domain Detection (clean with 'general' first, then detect)
        const preliminaryData = await Promise.all(
            safeFiles.map(file => universalCleaner.clean(file, 'general'))
        );

        // Merge preliminary data for domain detection (using SmartMerger)
        const mergedPreliminary = preliminaryData.length === 1
            ? preliminaryData[0]
            : SmartMerger.merge(preliminaryData).data;

        // Step 2: Detect Domain from the data structure
        const domain = domainDetector.detect(mergedPreliminary);
        console.log('[Director] Detected domain:', domain);

        // Step 3: Re-clean with CORRECT domain if not 'general'
        let mergedData: CleanedData;
        let cleaningLogs: string[];

        if (domain !== 'general') {
            console.log('[Director] Re-cleaning with', domain.toUpperCase(), 'domain protocol');
            const cleanedDatasets = await Promise.all(
                safeFiles.map(file => universalCleaner.clean(file, domain))
            );
            mergedData = cleanedDatasets.length === 1
                ? cleanedDatasets[0]
                : SmartMerger.merge(cleanedDatasets).data;
            cleaningLogs = cleanedDatasets.flatMap(d => d.cleaningLog);
        } else {
            // Already cleaned with 'general', use that
            mergedData = mergedPreliminary;
            cleaningLogs = preliminaryData.flatMap(d => d.cleaningLog);
        }

        console.log('[Director] Data cleaned:', mergedData.rowCount, 'rows,', mergedData.columnCount, 'columns');
        console.log('[Director] Cleaning logs:', cleaningLogs.length, 'entries');

        // Step 4: RAG Lookup - Get SOP (with correct domain)
        const sop = getSOP(domain);
        console.log('[Director] Applied SOP from:', sop.source);

        // Step 5: Statistical Analysis
        const stats = statisticalAnalyzer.analyze(mergedData);
        console.log('[Director] Statistical analysis complete:', stats.models.length, 'models');

        // Step 6: Predictive Analysis (NEW)
        const forecast = ForecastEngine.analyze(mergedData, 6);
        if (forecast) {
            console.log(`[Director] Forecast generated: ${forecast.metric} trend is ${forecast.trend}`);
        }

        // Step 7: ML Lookup - Get user preferences
        const userFavorites = feedbackLoop.getPreferredCharts(domain);
        console.log('[Director] User favorites:', userFavorites);

        // Step 8: Generate Charts
        const charts = chartFactory.generate(mergedData, domain);
        console.log('[Director] Generated', charts.length, 'charts');

        // Step 9: Score Charts
        const scoredCharts = this.scoreCharts(charts, sop.chart_priorities, userFavorites);

        // Sort by score descending
        scoredCharts.sort((a, b) => b.score - a.score);

        // Step 10: Return Result with Stats, Forecast & Logs
        return {
            domain,
            sop,
            data: mergedData,
            charts: scoredCharts,
            stats,
            forecast,
            cleaningLogs,
            timestamp: new Date()
        };
    }
    /**
     * Score charts based on SOP priorities and ML preferences
     */
    private scoreCharts(
        charts: ChartConfig[],
        sopPriorities: ChartType[],
        userFavorites: ChartType[]
    ): ChartConfig[] {
        return charts.map(chart => {
            let score = 0;
            const scoringDetails: string[] = [];

            // SOP Priority Bonus (+10 base, +N for position)
            const sopIndex = sopPriorities.indexOf(chart.type);
            if (sopIndex !== -1) {
                const sopBonus = 10 + (sopPriorities.length - sopIndex);
                score += sopBonus;
                scoringDetails.push(`+${sopBonus} SOP Priority (rank ${sopIndex + 1})`);
            }

            // ML User Preference Bonus (+20)
            if (userFavorites.includes(chart.type)) {
                score += 20;
                scoringDetails.push('+20 User Preference');
            }

            // Data quality bonus (+5 if good data)
            const data = chart.data as Record<string, unknown>[];
            if (data && data.length >= 5) {
                score += 5;
                scoringDetails.push('+5 Data Quality');
            }

            return {
                ...chart,
                score,
                reasoning: `${chart.reasoning} | Scoring: ${scoringDetails.join(', ') || 'Base score'}`
            };
        });
    }
}

// Singleton instance
export const analysisDirector = new AnalysisDirector();

export default analysisDirector;
