import React from 'react';

interface GlassCardProps {
    children: React.ReactNode;
    title: string;
    score?: number;
    badge?: string;
    selected?: boolean;
    onSelect?: () => void;
    className?: string;
}

export const GlassCard: React.FC<GlassCardProps> = ({
    children,
    title,
    score,
    badge,
    selected,
    onSelect,
    className
}) => {
    return (
        <div
            onClick={onSelect}
            className={`
        relative overflow-hidden rounded-xl border p-5 transition-all duration-300 cursor-pointer group
        ${selected
                    ? 'bg-indigo-900/40 border-indigo-500 shadow-[0_0_20px_rgba(99,102,241,0.3)]'
                    : 'bg-gray-800/40 border-gray-700 hover:border-gray-500 hover:bg-gray-800/60'
                }
        backdrop-blur-md
        ${className || ''}
      `}
        >
            {/* Header Row */}
            <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-2">
                    {/* Checkbox Appearance */}
                    <div className={`w-5 h-5 rounded border flex items-center justify-center ${selected ? 'bg-indigo-600 border-indigo-500' : 'border-gray-600 bg-gray-900/50'}`}>
                        {selected && <span className="text-xs text-white">✓</span>}
                    </div>

                    <div>
                        <h3 className="font-semibold text-gray-100 text-sm">{title}</h3>
                        {badge && <span className="text-[10px] uppercase tracking-wider text-gray-400">{badge}</span>}
                    </div>
                </div>

                {/* Score Badge (The Green Number) */}
                {score !== undefined && (
                    <div className="text-right">
                        <div className={`text-xl font-bold ${score > 70 ? 'text-emerald-400' : 'text-yellow-400'}`}>
                            {score}
                        </div>
                        <div className="text-[10px] text-gray-500 uppercase">Score</div>
                    </div>
                )}
            </div>

            {/* Content Area */}
            <div className="relative z-10 transition-opacity duration-300">
                {children}
            </div>
        </div>
    );
};

export default GlassCard;
