/**
 * DataChat.tsx - "Talk to Your Data" Assistant
 * 
 * A floating chat window that lets users interrogate their analysis.
 * Uses RAG (Retrieval-Augmented Generation) for context-aware responses.
 */

import React, { useState, useEffect, useRef } from 'react';
import { MessageCircle, X, Send } from 'lucide-react';
import { ragEngine } from '../engine/rag/RAGEngine';
import type { VectorSearchResult } from '../engine/rag/VectorDB';
import type { PipelineResult } from '../types';

interface DataChatProps {
    context: PipelineResult;
}

interface Message {
    role: 'user' | 'ai';
    text: string;
    sources?: VectorSearchResult[];
    confidence?: number;
}

export const DataChat: React.FC<DataChatProps> = ({ context }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [messages, setMessages] = useState<Message[]>([]);
    const [input, setInput] = useState('');
    const [loading, setLoading] = useState(false);
    const [_showSources, _setShowSources] = useState<number | null>(null);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    // Auto-scroll to bottom when messages change
    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const handleSend = async () => {
        if (!input.trim() || loading) return;

        const userMsg = input.trim();
        setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
        setInput('');
        setLoading(true);

        try {
            // Build data context from current analysis
            const modelInsights = context.stats.models
                .map(m => `${m.feature}: R²=${m.rSquared?.toFixed(2)}, r=${m.correlation?.toFixed(2)}`)
                .join('; ');

            const chartList = context.charts
                .filter(c => c.score >= 10)
                .map(c => `${c.title} (${c.type})`)
                .join(', ');

            const dataSummary = `
Dataset: ${context.stats.rowCount} rows × ${context.stats.columnCount} columns
Domain: ${context.domain}
Protocol: ${context.sop.source}
Objective: ${context.sop.objective}
Numeric Columns: ${context.data.numericColumns.slice(0, 6).join(', ')}
Models: ${modelInsights || 'None'}
Charts: ${chartList || 'None'}
            `.trim();

            // Use RAG Engine for enhanced response
            const response = await ragEngine.answerDataQuestion(
                userMsg,
                {
                    rowCount: context.stats.rowCount,
                    columns: [...context.data.numericColumns, ...context.data.categoricalColumns],
                    domain: context.domain,
                    summary: dataSummary
                }
            );

            setMessages(prev => [...prev, {
                role: 'ai',
                text: response.answer,
                sources: response.sources,
                confidence: response.confidence
            }]);
        } catch (error) {
            console.error('[DataChat] Error:', error);
            setMessages(prev => [...prev, {
                role: 'ai',
                text: 'Sorry, I encountered an error processing your question. Please try again.'
            }]);
        } finally {
            setLoading(false);
        }
    };

    const handleKeyDown = (e: React.KeyboardEvent) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSend();
        }
    };

    // Floating button when closed
    if (!isOpen) {
        return (
            <button
                onClick={() => setIsOpen(true)}
                className="data-chat-fab"
                title="Ask AI about your data"
            >
                <MessageCircle size={24} />
                <span>Ask AI</span>
            </button>
        );
    }

    // Chat window when open
    return (
        <div className="data-chat-window">
            {/* Header */}
            <div className="data-chat-header">
                <div className="data-chat-header-info">
                    <h3>Data Assistant</h3>
                    <span className="data-chat-domain">{context.domain.toUpperCase()}</span>
                </div>
                <button onClick={() => setIsOpen(false)} className="data-chat-close">
                    <X size={20} />
                </button>
            </div>

            {/* Messages Area */}
            <div className="data-chat-messages">
                {messages.length === 0 && (
                    <div className="data-chat-welcome">
                        <p className="wave">👋</p>
                        <p>I've analyzed your <strong>{context.domain}</strong> data.</p>
                        <p className="hint">Try asking:</p>
                        <ul>
                            <li>"What patterns do you see?"</li>
                            <li>"Why were rows removed?"</li>
                            <li>"Which columns correlate?"</li>
                        </ul>
                    </div>
                )}

                {messages.map((msg, i) => (
                    <div
                        key={i}
                        className={`data-chat-message ${msg.role === 'user' ? 'user' : 'ai'}`}
                    >
                        {msg.text}
                    </div>
                ))}

                {loading && (
                    <div className="data-chat-message ai loading">
                        <span className="dot"></span>
                        <span className="dot"></span>
                        <span className="dot"></span>
                    </div>
                )}

                <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <div className="data-chat-input-area">
                <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="Ask about your data..."
                    disabled={loading}
                    className="data-chat-input"
                />
                <button
                    onClick={handleSend}
                    disabled={loading || !input.trim()}
                    className="data-chat-send"
                >
                    <Send size={18} />
                </button>
            </div>
        </div>
    );
};

export default DataChat;
