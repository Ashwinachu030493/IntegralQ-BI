/**
 * Login Page Component
 * 
 * Provides login and signup forms with a modern glassmorphism design.
 */

import React, { useState } from 'react';
import { useAuth } from '../auth/AuthProvider';
import './LoginPage.css';

interface LoginPageProps {
    onSuccess?: () => void;
}

export function LoginPage({ onSuccess }: LoginPageProps) {
    const { signIn, signUp, isLoading } = useAuth();
    const [isSignUp, setIsSignUp] = useState(false);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [name, setName] = useState('');
    const [error, setError] = useState<string | null>(null);
    const [success, setSuccess] = useState<string | null>(null);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);
        setSuccess(null);

        if (!email || !password) {
            setError('Please fill in all fields');
            return;
        }

        if (isSignUp) {
            const result = await signUp(email, password, name);
            if (result.error) {
                setError(result.error);
            } else {
                setSuccess('Account created! You can now sign in.');
                setIsSignUp(false);
            }
        } else {
            const result = await signIn(email, password);
            if (result.error) {
                setError(result.error);
            } else {
                onSuccess?.();
            }
        }
    };

    return (
        <div className="login-page">
            <div className="login-container">
                <div className="login-header">
                    <h1 className="login-logo">IntegralQ</h1>
                    <p className="login-subtitle">Enterprise Business Intelligence</p>
                </div>

                <form className="login-form" onSubmit={handleSubmit}>
                    <h2 className="form-title">{isSignUp ? 'Create Account' : 'Welcome Back'}</h2>

                    {error && (
                        <div className="form-error">
                            <span className="error-icon">⚠</span>
                            {error}
                        </div>
                    )}

                    {success && (
                        <div className="form-success">
                            <span className="success-icon">✓</span>
                            {success}
                        </div>
                    )}

                    {isSignUp && (
                        <div className="form-group">
                            <label htmlFor="name">Full Name</label>
                            <input
                                type="text"
                                id="name"
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                placeholder="John Doe"
                                autoComplete="name"
                            />
                        </div>
                    )}

                    <div className="form-group">
                        <label htmlFor="email">Email Address</label>
                        <input
                            type="email"
                            id="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            placeholder="you@company.com"
                            autoComplete="email"
                            required
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="password">Password</label>
                        <input
                            type="password"
                            id="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder="••••••••"
                            autoComplete={isSignUp ? 'new-password' : 'current-password'}
                            required
                            minLength={6}
                        />
                    </div>

                    <button
                        type="submit"
                        className="login-button"
                        disabled={isLoading}
                    >
                        {isLoading ? 'Processing...' : (isSignUp ? 'Create Account' : 'Sign In')}
                    </button>

                    <div className="form-footer">
                        <span>{isSignUp ? 'Already have an account?' : "Don't have an account?"}</span>
                        <button
                            type="button"
                            className="toggle-button"
                            onClick={() => {
                                setIsSignUp(!isSignUp);
                                setError(null);
                                setSuccess(null);
                            }}
                        >
                            {isSignUp ? 'Sign In' : 'Sign Up'}
                        </button>
                    </div>
                </form>

                <div className="login-demo">
                    <p>Demo Mode: Use any email/password to login</p>
                </div>
            </div>
        </div>
    );
}

export default LoginPage;
