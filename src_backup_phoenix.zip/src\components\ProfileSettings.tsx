/**
 * ProfileSettings.tsx - User Profile Settings Modal
 * 
 * Allows users to update their profile information:
 * - Name
 * - Avatar
 * - Email (read-only, from auth)
 */

import React, { useState, useEffect } from 'react';
import { X, User, Mail, Camera, Save, Loader2 } from 'lucide-react';
import { useAuth } from '../auth/AuthProvider';
import './ProfileSettings.css';

interface ProfileSettingsProps {
    isOpen: boolean;
    onClose: () => void;
}

export const ProfileSettings: React.FC<ProfileSettingsProps> = ({
    isOpen,
    onClose
}) => {
    const { user } = useAuth();
    const [name, setName] = useState('');
    const [avatarUrl, setAvatarUrl] = useState('');
    const [saving, setSaving] = useState(false);
    const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

    useEffect(() => {
        if (user) {
            setName(user.name || '');
            setAvatarUrl(user.avatar_url || '');
        }
    }, [user, isOpen]);

    if (!isOpen || !user) return null;

    const handleSave = async () => {
        setSaving(true);
        setMessage(null);

        try {
            // Update user profile in localStorage (mock implementation)
            const stored = localStorage.getItem('integralq_session');
            if (stored) {
                const session = JSON.parse(stored);
                session.user = {
                    ...session.user,
                    name,
                    avatar_url: avatarUrl
                };
                localStorage.setItem('integralq_session', JSON.stringify(session));

                // Reload page to reflect changes
                setMessage({ type: 'success', text: 'Profile updated! Refreshing...' });
                setTimeout(() => {
                    window.location.reload();
                }, 1000);
            }
        } catch (error) {
            setMessage({ type: 'error', text: 'Failed to update profile' });
        } finally {
            setSaving(false);
        }
    };

    const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            // Convert to data URL for demo (in production, upload to storage)
            const reader = new FileReader();
            reader.onloadend = () => {
                setAvatarUrl(reader.result as string);
            };
            reader.readAsDataURL(file);
        }
    };

    return (
        <div className="settings-modal-overlay" onClick={onClose}>
            <div className="settings-modal" onClick={e => e.stopPropagation()}>
                <div className="settings-modal-header">
                    <h2><User size={20} /> Profile Settings</h2>
                    <button className="settings-close" onClick={onClose}>
                        <X size={20} />
                    </button>
                </div>

                <div className="settings-content">
                    {/* Avatar */}
                    <div className="settings-avatar-section">
                        <div className="settings-avatar">
                            {avatarUrl ? (
                                <img src={avatarUrl} alt="Avatar" />
                            ) : (
                                <div className="avatar-placeholder">
                                    {name ? name.substring(0, 2).toUpperCase() : user.email.substring(0, 2).toUpperCase()}
                                </div>
                            )}
                            <label className="avatar-upload-btn">
                                <Camera size={16} />
                                <input
                                    type="file"
                                    accept="image/*"
                                    onChange={handleAvatarUpload}
                                    hidden
                                />
                            </label>
                        </div>
                        <p className="avatar-hint">Click camera to upload photo</p>
                    </div>

                    {/* Form */}
                    <div className="settings-form">
                        <div className="form-group">
                            <label>
                                <User size={16} />
                                Full Name
                            </label>
                            <input
                                type="text"
                                value={name}
                                onChange={e => setName(e.target.value)}
                                placeholder="Enter your name"
                            />
                        </div>

                        <div className="form-group">
                            <label>
                                <Mail size={16} />
                                Email Address
                            </label>
                            <input
                                type="email"
                                value={user.email}
                                disabled
                                className="disabled"
                            />
                            <span className="form-hint">Email cannot be changed</span>
                        </div>

                        <div className="form-group">
                            <label>Role</label>
                            <div className="role-badge">{user.role || 'Member'}</div>
                        </div>

                        {message && (
                            <div className={`settings-message ${message.type}`}>
                                {message.text}
                            </div>
                        )}

                        <button
                            className="settings-save-btn"
                            onClick={handleSave}
                            disabled={saving}
                        >
                            {saving ? (
                                <>
                                    <Loader2 size={18} className="spinner" />
                                    Saving...
                                </>
                            ) : (
                                <>
                                    <Save size={18} />
                                    Save Changes
                                </>
                            )}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ProfileSettings;
