/**
 * UserProfile.tsx - User Profile Component
 * 
 * Displays user avatar, name, and provides sign out functionality.
 * Shows in the dashboard header.
 */

import React, { useState } from 'react';
import { User, LogOut, Settings, ChevronDown } from 'lucide-react';
import { useAuth } from '../auth/AuthProvider';
import { ProfileSettings } from './ProfileSettings';
import { Preferences } from './Preferences';
import './UserProfile.css';

export const UserProfile: React.FC = () => {
    const { user, signOut, isAuthenticated } = useAuth();
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [showProfileSettings, setShowProfileSettings] = useState(false);
    const [showPreferences, setShowPreferences] = useState(false);

    if (!isAuthenticated || !user) {
        return null;
    }

    const handleSignOut = async () => {
        setIsMenuOpen(false);
        await signOut();
    };

    const handleOpenProfileSettings = () => {
        setIsMenuOpen(false);
        setShowProfileSettings(true);
    };

    const handleOpenPreferences = () => {
        setIsMenuOpen(false);
        setShowPreferences(true);
    };

    // Generate avatar initials from name or email
    const getInitials = () => {
        if (user.name) {
            const parts = user.name.split(' ');
            return parts.length > 1
                ? `${parts[0][0]}${parts[1][0]}`.toUpperCase()
                : parts[0].substring(0, 2).toUpperCase();
        }
        return user.email.substring(0, 2).toUpperCase();
    };

    // Generate background color from email (consistent per user)
    const getAvatarColor = () => {
        const colors = [
            'linear-gradient(135deg, #6366f1, #8b5cf6)',
            'linear-gradient(135deg, #ec4899, #f43f5e)',
            'linear-gradient(135deg, #22c55e, #14b8a6)',
            'linear-gradient(135deg, #f97316, #eab308)',
            'linear-gradient(135deg, #3b82f6, #06b6d4)'
        ];
        const hash = user.email.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
        return colors[hash % colors.length];
    };

    return (
        <>
            <div className="user-profile">
                <button
                    className="user-profile-trigger"
                    onClick={() => setIsMenuOpen(!isMenuOpen)}
                >
                    {user.avatar_url ? (
                        <img
                            src={user.avatar_url}
                            alt={user.name || user.email}
                            className="user-avatar-image"
                        />
                    ) : (
                        <div
                            className="user-avatar-initials"
                            style={{ background: getAvatarColor() }}
                        >
                            {getInitials()}
                        </div>
                    )}
                    <div className="user-info">
                        <span className="user-name">{user.name || 'User'}</span>
                        <span className="user-email">{user.email}</span>
                    </div>
                    <ChevronDown
                        size={16}
                        className={`user-chevron ${isMenuOpen ? 'open' : ''}`}
                    />
                </button>

                {isMenuOpen && (
                    <>
                        <div
                            className="user-menu-backdrop"
                            onClick={() => setIsMenuOpen(false)}
                        />
                        <div className="user-menu">
                            <div className="user-menu-header">
                                <div
                                    className="user-avatar-large"
                                    style={{ background: getAvatarColor() }}
                                >
                                    {user.avatar_url ? (
                                        <img src={user.avatar_url} alt="" />
                                    ) : (
                                        getInitials()
                                    )}
                                </div>
                                <div className="user-menu-info">
                                    <span className="user-menu-name">{user.name || 'User'}</span>
                                    <span className="user-menu-email">{user.email}</span>
                                    {user.role && (
                                        <span className="user-menu-role">{user.role}</span>
                                    )}
                                </div>
                            </div>

                            <div className="user-menu-divider" />

                            <button className="user-menu-item" onClick={handleOpenProfileSettings}>
                                <User size={18} />
                                <span>Profile Settings</span>
                            </button>

                            <button className="user-menu-item" onClick={handleOpenPreferences}>
                                <Settings size={18} />
                                <span>Preferences</span>
                            </button>

                            <div className="user-menu-divider" />

                            <button
                                className="user-menu-item danger"
                                onClick={handleSignOut}
                            >
                                <LogOut size={18} />
                                <span>Sign Out</span>
                            </button>
                        </div>
                    </>
                )}
            </div>

            {/* Modals */}
            <ProfileSettings
                isOpen={showProfileSettings}
                onClose={() => setShowProfileSettings(false)}
            />
            <Preferences
                isOpen={showPreferences}
                onClose={() => setShowPreferences(false)}
            />
        </>
    );
};

export default UserProfile;

