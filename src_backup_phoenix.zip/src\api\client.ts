/**
 * API Client for IntegralQ-BI Backend
 * 
 * Handles communication with the Python FastAPI backend.
 * Provides fallback to client-side processing if backend is unavailable.
 */

const API_BASE_URL = 'http://localhost:8000/api';

export interface BackendAnalysisResult {
    success: boolean;
    domain: string;
    row_count: number;
    column_count: number;
    numeric_columns: string[];
    categorical_columns: string[];
    date_columns: string[];
    cleaning_log: string[];
    statistics: {
        row_count: number;
        column_count: number;
        numeric_summaries: Record<string, { mean: number; std: number; min: number; max: number; median: number }>;
        correlations: Array<{ feature_a: string; feature_b: string; correlation: number; insight: string }>;
        models: Array<{ feature: string; correlation: number; insight: string; type: string }>;
    };
    forecast: {
        metric: string;
        date_column: string;
        trend: 'Upward' | 'Downward' | 'Stable';
        slope: number;
        confidence: string;
        historical_data: Record<string, unknown>[];
        forecast_data: Record<string, unknown>[];
    } | null;
}

export interface HealthCheckResult {
    status: string;
    version: string;
}

class APIClient {
    private baseUrl: string;
    private isBackendAvailable: boolean | null = null;

    constructor(baseUrl: string = API_BASE_URL) {
        this.baseUrl = baseUrl;
    }

    /**
     * Check if backend is available
     */
    async checkHealth(): Promise<boolean> {
        try {
            const response = await fetch(`${this.baseUrl}/health`, {
                method: 'GET',
                signal: AbortSignal.timeout(3000) // 3s timeout
            });

            if (response.ok) {
                const data: HealthCheckResult = await response.json();
                console.log(`[API] Backend connected: v${data.version}`);
                this.isBackendAvailable = true;
                return true;
            }
        } catch (error) {
            console.log('[API] Backend unavailable, using client-side processing');
        }

        this.isBackendAvailable = false;
        return false;
    }

    /**
     * Analyze files using backend API
     */
    async analyzeFiles(files: File[]): Promise<BackendAnalysisResult> {
        const formData = new FormData();
        files.forEach(file => formData.append('files', file));

        const response = await fetch(`${this.baseUrl}/analyze`, {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.detail || 'Analysis failed');
        }

        return response.json();
    }

    /**
     * Upload a single file for metadata inspection
     */
    async uploadFile(file: File): Promise<{ filename: string; size_bytes: number; extension: string }> {
        const formData = new FormData();
        formData.append('file', file);

        const response = await fetch(`${this.baseUrl}/upload`, {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.detail || 'Upload failed');
        }

        return response.json();
    }

    /**
     * Check if we should use backend or client-side processing
     */
    async shouldUseBackend(): Promise<boolean> {
        if (this.isBackendAvailable === null) {
            await this.checkHealth();
        }
        return this.isBackendAvailable === true;
    }

    /**
     * Get backend status for UI display
     */
    getBackendStatus(): 'connected' | 'disconnected' | 'unknown' {
        if (this.isBackendAvailable === null) return 'unknown';
        return this.isBackendAvailable ? 'connected' : 'disconnected';
    }
}

// Singleton instance
export const apiClient = new APIClient();

export default apiClient;
