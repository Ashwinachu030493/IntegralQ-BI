/**
 * Auth Context Provider
 * 
 * Provides authentication state to the entire React app.
 */

import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import { authService, type AuthState } from './authService';

interface AuthContextType extends AuthState {
    signIn: (email: string, password: string) => Promise<{ error: string | null }>;
    signUp: (email: string, password: string, name?: string) => Promise<{ error: string | null }>;
    signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
    const [state, setState] = useState<AuthState>(() => authService.getState());

    useEffect(() => {
        // Subscribe to auth state changes
        const unsubscribe = authService.subscribe((newState) => {
            setState(newState);
        });

        return () => unsubscribe();
    }, []);

    const signIn = async (email: string, password: string) => {
        const result = await authService.signIn(email, password);
        return { error: result.error };
    };

    const signUp = async (email: string, password: string, name?: string) => {
        const result = await authService.signUp(email, password, name);
        return { error: result.error };
    };

    const signOut = async () => {
        await authService.signOut();
    };

    return (
        <AuthContext.Provider value={{ ...state, signIn, signUp, signOut }}>
            {children}
        </AuthContext.Provider>
    );
}

export function useAuth() {
    const context = useContext(AuthContext);
    if (!context) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
}

export default AuthProvider;
