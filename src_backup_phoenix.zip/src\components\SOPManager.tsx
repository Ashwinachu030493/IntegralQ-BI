import React, { useState } from 'react';
import { useDropzone } from 'react-dropzone'; // Ensure npm install react-dropzone
import './SOPManager.css';

export const SOPManager: React.FC = () => {
    const [sops, setSops] = useState([
        { id: 1, name: 'HR_Policies_2025.pdf', status: 'indexed', date: '2025-10-12' },
        { id: 2, name: 'Finance_Standard_Operating_Procedures.docx', status: 'indexed', date: '2025-10-15' }
    ]);
    const [isUploading, setIsUploading] = useState(false);

    const onDrop = async (acceptedFiles: File[]) => {
        setIsUploading(true);

        // Simulation of RAG Ingestion Process
        setTimeout(() => {
            const newFiles = acceptedFiles.map((file, idx) => ({
                id: Date.now() + idx,
                name: file.name,
                status: 'indexed',
                date: new Date().toISOString().split('T')[0]
            }));

            setSops([...sops, ...newFiles]);
            setIsUploading(false);
        }, 2000);
    };

    const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop });

    return (
        <div className="sop-manager animate-in fade-in duration-500">
            <div className="sop-header">
                <h2>📚 Knowledge Base Manager</h2>
                <p>Upload SOP documents here. The AI will index them to generate domain-aware insights.</p>
            </div>

            {/* Upload Area */}
            <div
                {...getRootProps()}
                className={`upload-zone border-2 border-dashed rounded-xl p-10 text-center cursor-pointer transition-all
          ${isDragActive ? 'border-indigo-500 bg-indigo-900/20' : 'border-gray-700 hover:border-indigo-400 hover:bg-gray-800/50'}
        `}
            >
                <input {...getInputProps()} />
                <div className="text-4xl mb-4">📄</div>
                {isUploading ? (
                    <div className="flex flex-col items-center">
                        <div className="loading-spinner mb-2"></div>
                        <p>Chunking & Vectorizing content...</p>
                    </div>
                ) : (
                    <div>
                        <p className="text-lg font-medium text-gray-200">Drop PDF or Text files here</p>
                        <p className="text-sm text-gray-500 mt-2">Maximum file size: 10MB</p>
                    </div>
                )}
            </div>

            {/* File List */}
            <div className="sop-list mt-8">
                <h3>Active Protocols ({sops.length})</h3>
                <div className="space-y-3 mt-4">
                    {sops.map(sop => (
                        <div key={sop.id} className="sop-item indexed flex justify-between items-center bg-gray-800 p-4 rounded-lg border border-gray-700">
                            <div className="flex items-center gap-3">
                                <span className="text-xl">📑</span>
                                <div>
                                    <p className="sop-name font-medium text-gray-200">{sop.name}</p>
                                    <p className="text-xs text-gray-500">Indexed on {sop.date}</p>
                                </div>
                            </div>
                            <div className="sop-status flex items-center gap-2 text-green-400 text-sm bg-green-900/20 px-3 py-1 rounded-full">
                                <span className="w-2 h-2 rounded-full bg-green-400"></span>
                                Vectorized
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};
