/**
 * ConnectDataSource.tsx - Data Source Connection UI
 * 
 * Modal for connecting to external data sources:
 * - Google Sheets
 * - REST APIs
 * - SQL Databases
 */

import React, { useState } from 'react';
import { X, Sheet, Globe, Database, Loader2, CheckCircle, AlertCircle } from 'lucide-react';
import { dataConnectors, type ConnectorResult } from '../engine/connectors/DataConnectors';
import './ConnectDataSource.css';

interface ConnectDataSourceProps {
    isOpen: boolean;
    onClose: () => void;
    onConnect: (result: ConnectorResult) => void;
}

type SourceType = 'google-sheets' | 'rest-api' | 'sql';

export const ConnectDataSource: React.FC<ConnectDataSourceProps> = ({
    isOpen,
    onClose,
    onConnect
}) => {
    const [sourceType, setSourceType] = useState<SourceType>('google-sheets');
    const [url, setUrl] = useState('');
    const [apiKey, setApiKey] = useState('');
    const [loading, setLoading] = useState(false);
    const [result, setResult] = useState<ConnectorResult | null>(null);

    if (!isOpen) return null;

    const handleConnect = async () => {
        setLoading(true);
        setResult(null);

        try {
            let connectorResult: ConnectorResult;

            switch (sourceType) {
                case 'google-sheets':
                    const sheetsConnector = dataConnectors.getConnector('google-sheets');
                    connectorResult = await sheetsConnector.fetch(url);
                    break;

                case 'rest-api':
                    const apiConnector = dataConnectors.getConnector('rest-api');
                    connectorResult = await apiConnector.fetch(url, {
                        headers: apiKey ? { 'Authorization': `Bearer ${apiKey}` } : {}
                    });
                    break;

                case 'sql':
                    const sqlConnector = dataConnectors.getConnector('sql');
                    connectorResult = await sqlConnector.query('default', url);
                    break;

                default:
                    throw new Error('Unknown source type');
            }

            setResult(connectorResult);

            if (connectorResult.success) {
                setTimeout(() => {
                    onConnect(connectorResult);
                    onClose();
                }, 1500);
            }
        } catch (error) {
            setResult({
                success: false,
                data: [],
                columns: [],
                rowCount: 0,
                source: sourceType,
                fetchedAt: new Date(),
                error: error instanceof Error ? error.message : 'Connection failed'
            });
        } finally {
            setLoading(false);
        }
    };

    const getPlaceholder = () => {
        switch (sourceType) {
            case 'google-sheets':
                return 'https://docs.google.com/spreadsheets/d/...';
            case 'rest-api':
                return 'https://api.example.com/data';
            case 'sql':
                return 'SELECT * FROM table_name LIMIT 100';
        }
    };

    const getLabel = () => {
        switch (sourceType) {
            case 'google-sheets':
                return 'Google Sheets URL';
            case 'rest-api':
                return 'API Endpoint URL';
            case 'sql':
                return 'SQL Query';
        }
    };

    return (
        <div className="connect-modal-overlay" onClick={onClose}>
            <div className="connect-modal" onClick={e => e.stopPropagation()}>
                <div className="connect-modal-header">
                    <h2>Connect Data Source</h2>
                    <button className="connect-modal-close" onClick={onClose}>
                        <X size={20} />
                    </button>
                </div>

                <div className="connect-source-types">
                    <button
                        className={`source-type-btn ${sourceType === 'google-sheets' ? 'active' : ''}`}
                        onClick={() => setSourceType('google-sheets')}
                    >
                        <Sheet size={24} />
                        <span>Google Sheets</span>
                    </button>
                    <button
                        className={`source-type-btn ${sourceType === 'rest-api' ? 'active' : ''}`}
                        onClick={() => setSourceType('rest-api')}
                    >
                        <Globe size={24} />
                        <span>REST API</span>
                    </button>
                    <button
                        className={`source-type-btn ${sourceType === 'sql' ? 'active' : ''}`}
                        onClick={() => setSourceType('sql')}
                    >
                        <Database size={24} />
                        <span>SQL Database</span>
                    </button>
                </div>

                <div className="connect-form">
                    <div className="form-group">
                        <label>{getLabel()}</label>
                        {sourceType === 'sql' ? (
                            <textarea
                                value={url}
                                onChange={e => setUrl(e.target.value)}
                                placeholder={getPlaceholder()}
                                rows={4}
                            />
                        ) : (
                            <input
                                type="text"
                                value={url}
                                onChange={e => setUrl(e.target.value)}
                                placeholder={getPlaceholder()}
                            />
                        )}
                    </div>

                    {sourceType !== 'sql' && (
                        <div className="form-group">
                            <label>API Key (Optional)</label>
                            <input
                                type="password"
                                value={apiKey}
                                onChange={e => setApiKey(e.target.value)}
                                placeholder="Enter API key if required"
                            />
                            <span className="form-hint">
                                {sourceType === 'google-sheets'
                                    ? 'Required for private sheets. Get one from Google Cloud Console.'
                                    : 'Will be sent as Bearer token in Authorization header.'}
                            </span>
                        </div>
                    )}

                    {result && (
                        <div className={`connect-result ${result.success ? 'success' : 'error'}`}>
                            {result.success ? (
                                <>
                                    <CheckCircle size={20} />
                                    <span>
                                        Connected! Found {result.rowCount} rows with {result.columns.length} columns.
                                    </span>
                                </>
                            ) : (
                                <>
                                    <AlertCircle size={20} />
                                    <span>{result.error}</span>
                                </>
                            )}
                        </div>
                    )}

                    <button
                        className="connect-btn"
                        onClick={handleConnect}
                        disabled={loading || !url.trim()}
                    >
                        {loading ? (
                            <>
                                <Loader2 size={18} className="spinner" />
                                Connecting...
                            </>
                        ) : (
                            'Connect & Import'
                        )}
                    </button>
                </div>

                <div className="connect-tips">
                    <h4>Tips</h4>
                    {sourceType === 'google-sheets' && (
                        <ul>
                            <li>For public sheets: File → Share → Anyone with link</li>
                            <li>First row should contain column headers</li>
                            <li>Supported: .xlsx-style data only</li>
                        </ul>
                    )}
                    {sourceType === 'rest-api' && (
                        <ul>
                            <li>Endpoint should return JSON array</li>
                            <li>Auto-detects: data, items, results paths</li>
                            <li>CORS must allow browser requests</li>
                        </ul>
                    )}
                    {sourceType === 'sql' && (
                        <ul>
                            <li>Configure database in backend first</li>
                            <li>Use LIMIT to prevent large result sets</li>
                            <li>Read-only queries recommended</li>
                        </ul>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ConnectDataSource;
